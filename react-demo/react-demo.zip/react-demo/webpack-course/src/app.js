import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(
  <h1 class="test">Hello, From React!</h1>,
  document.getElementById("react-root")
)