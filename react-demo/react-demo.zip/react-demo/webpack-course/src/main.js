/**
 * Author: 米斯特吴
 * QQ: 27732357
 * 群号: 21227101
 * 内容: node和谷歌浏览器调试工具
 */
require("babel-runtime/regenerator")
require("babel-register")
require("webpack-hot-middleware/client?reload=true")
require("./main.css")
require("./index.html")
require("./app")
// debugger


