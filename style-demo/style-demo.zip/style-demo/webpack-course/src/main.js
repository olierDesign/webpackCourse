/**
 * Author: 米斯特吴
 * QQ: 27732357
 * 群号: 21227101
 * 内容: node和谷歌浏览器调试工具
 */
require("babel-runtime/regenerator")
require("webpack-hot-middleware/client?reload=true")
// require("./main.css")
// require("./main.sass")
// require("./main.less")
require("./main.styl")
require("./index.html")
// debugger
// var a = async args => {
//   const {a , b} = args
//   await console.log("Hello Future!",a,b,)
//   console.log("Done")
// }

// a({a:1,b:2})

